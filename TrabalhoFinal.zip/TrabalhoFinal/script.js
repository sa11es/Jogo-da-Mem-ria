const arrayCartas = [
    "🍊", "🍊", "🍎", "🍎", "🍌", "🍌", "🍉", "🍉",
    "🍇", "🍇", "🍒", "🍒", "🍓", "🍓", "🍍", "🍍",
    "🥥", "🥥", "🍋", "🍋", "🍐", "🍐", "🥝", "🥝"
];

let tabuleiro = document.getElementById("tabuleiro");
let botaoJogo = document.getElementById("botao-jogo");
let cartasViradas = [];
let cartasCorretas = [];

// Função para embaralhar as cartas
function embaralhar(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

let dificuldade = "medio"; 

function definirDificuldade(novaDificuldade) {
    dificuldade = novaDificuldade;
    iniciarJogo(); 
}

// Função para ajustar o número de pares de acordo com a dificuldade
function ajustarCartasPorDificuldade() {
    let pares;
    switch (dificuldade) {
        case "facil":
            pares = 6; 
            break;
        case "medio":
            pares = 9; 
            break;
        case "dificil":
            pares = 12; 
            break;
    }
    
    const cartasSelecionadas = arrayCartas.slice(0, pares * 2); 
    return cartasSelecionadas;
}

function criarTabuleiro() {
    tabuleiro.innerHTML = "";
    const cartasParaJogo = ajustarCartasPorDificuldade();
    embaralhar(cartasParaJogo);
    cartasParaJogo.forEach((valor) => {
        const carta = document.createElement("div");
        carta.classList.add("carta");
        carta.dataset.valor = valor;
        carta.addEventListener("click", virarCarta);
        tabuleiro.appendChild(carta);
    });
}

// Função para virar a carta ao ser clicada
function virarCarta() {
    if (cartasViradas.length === 2) return;
    this.classList.add("virada");
    this.textContent = this.dataset.valor;
    cartasViradas.push(this);

    if (cartasViradas.length === 2) {
        setTimeout(verificarPar, 800);
    }
}

// Função para verificar se as cartas viradas formam um par
function verificarPar() {
    const [carta1, carta2] = cartasViradas;

    if (carta1.dataset.valor === carta2.dataset.valor) {
        cartasCorretas.push(carta1, carta2);
        cartasViradas = [];
        // Verifica se o número de cartas corretas é igual ao número de cartas do jogo
        if (cartasCorretas.length === ajustarCartasPorDificuldade().length) {
            setTimeout(() => {
                exibirMensagemVitoria(); 
            }, 500);
        }
    } else {
        cartasViradas.forEach(carta => {
            carta.classList.remove("virada");
            carta.textContent = "";
        });
        cartasViradas = [];
    }
}

// Função para exibir a mensagem de vitória
function exibirMensagemVitoria() {
    const mensagemVitoria = document.getElementById("mensagem-vitoria");
    mensagemVitoria.classList.remove("oculto");  
    mensagemVitoria.classList.add("visivel");  
}

// Função para esconder a mensagem de vitória ao reiniciar o jogo
function esconderMensagemVitoria() {
    const mensagemVitoria = document.getElementById("mensagem-vitoria");
    mensagemVitoria.classList.remove("visivel"); 
    mensagemVitoria.classList.add("oculto");  
}

// Função para reiniciar o jogo
function reiniciarJogo() {
    esconderMensagemVitoria();  
    cartasCorretas = [];
    cartasViradas = [];
    criarTabuleiro();
    tabuleiro.classList.remove("oculto");  
    botaoJogo.textContent = "Reiniciar";  
}

// Modificando a função do botão de reiniciar
botaoJogo.addEventListener("click", reiniciarJogo);


// Função para iniciar o jogo
function iniciarJogo() {
    cartasCorretas = [];
    cartasViradas = [];
    criarTabuleiro();
    tabuleiro.classList.remove("oculto");  
    botaoJogo.textContent = "Reiniciar";  
}

